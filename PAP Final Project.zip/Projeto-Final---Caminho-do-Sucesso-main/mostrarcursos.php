<?php 
    error_reporting(1);
    ob_start();
    session_start();

    // Inclua o arquivo onde a função LigaBD é definida
    include('ligacaobd.php'); // Certifique-se de que 'conexao.php' define a função LigaBD()
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="ISO-8859-1">
    <link rel="stylesheet" href="mos-cursos.css">
    <title>Mostrar Cursos</title>

</head>
<body>
    <section>
        <div class="background-section">
            <video src="Design sem nome (2).mp4" autoplay loop muted></video>
        </div>
          
        <div class="box">
            <div class="conteudo">
                <h1>Gestão de Cursos</h1>

            <div class="btn-voltar">
            <!-- Use a tag <a> corretamente para links -->
            <a href="Gestaobase.html" class="action_btn">Voltar</a>
        </div>

        <div class="btn-registar">
            <!-- Use a tag <a> corretamente para links -->
            <a href="registrar_curso.php" class="action_btn2">Registar</a>
        </div>

<?php
    // Verifique se a função LigaBD existe
    if (!function_exists('LigaBD')) {
        die("Erro: A função 'LigaBD' não foi encontrada. Verifique se o arquivo 'conexao.php' foi incluído corretamente.");
    }

    // Conecta ao banco de dados
    if ($con = LigaBD()) {
        // Exclui um curso, se o ID for passado
        if (isset($_GET["id"])) {
            $stm = $con->prepare("DELETE FROM cursos WHERE id_cursos = ?");
            $stm->bind_param("i", $_GET["id"]);                                 
            $stm->execute();
        }

        // Consulta a tabela de cursos
        $query = $con->query("SELECT * FROM cursos");

        echo '<table>';
        echo '<tr>
                <th>Nome do Curso</th>
                <th>Nome do Mentor</th>
                <th>Tipo de Área</th>
                <th>Material de Estudo</th>
                <th>Editar</th>
                <th>Eliminar</th>
              </tr>';

        // Exibe os resultados  
        while ($resultados = $query->fetch_assoc()) {
            echo "<tr>
                    <td>{$resultados['nome_curso']}</td>
                    <td>{$resultados['nome_mentor']}</td>
                    <td>{$resultados['tipo_area']}</td>
                    <td>{$resultados['material_estudo']}</td>
                    <td><a href='registrar_curso.php?' id={$resultados['id_cursos']}
                    
                    <div class='btn-editar'>Editar</a></td>

                    <td><button class='btn-eliminar' data-id='{$resultados['id_cursos']}'>Eliminar</button></td>
                    
                  </tr>";
        }

        echo '</table>';
        $con->close();
    } else {
        echo '<p>Erro ao conectar ao banco de dados.</p>';
    }

    ob_end_flush();
?>
    </div>
</div>

</section>

    <!-- Pop-up : "Tem a certeza que quer excluir? - Sim ou Não"-->
    <div class="modal-overlay" id="modalOverlay"></div>
    <div class="modal" id="confirmationModal">
        <div class="modal-content">
            <p>Tem a certeza que quer eliminar?</p>
            <button id="confirmYes">Sim</button>
            <button id="confirmNo">Não</button>
        </div>
    </div>

    <script>

        // Codigo de confirmaçao : "Tem a certeza que quer excluir? - Sim ou Não"
        const modal = document.getElementById("confirmationModal");
        const overlay = document.getElementById("modalOverlay");
        const confirmYes = document.getElementById("confirmYes");
        const confirmNo = document.getElementById("confirmNo");
        let deleteId = null;

        // Codigo para excluir os botões
        document.querySelectorAll(".btn-eliminar").forEach(button => {
            button.addEventListener("click", function () {
                deleteId = this.getAttribute("data-id"); // Obter o código do curso 
                modal.style.display = "block";
                overlay.style.display = "block"; 
            });
        });

        // Confirmação para excluir os botões
        confirmYes.addEventListener("click", function () {
            if (deleteId) {
                window.location.href = `mostrarcursos.php?id=${deleteId}`;
            }
        });

        // Cancelar a exclusão dos botões
        confirmNo.addEventListener("click", function () {
            modal.style.display = "none"; 
            overlay.style.display = "none";
            deleteId = null; // Redefinir ID
        });

        // Ocultar a mensagem quando é clicada (Sobrepoe-se a confirmação do texto)
        overlay.addEventListener("click", function () {
            modal.style.display = "none";
            overlay.style.display = "none";
            deleteId = null; // Redefinir ID
        });

    </script>

</body>

</html>