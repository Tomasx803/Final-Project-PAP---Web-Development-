<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="loginsocio.css">
    <title>Login</title>
</head>

<body>
    <section>
        <div class="background-section">
            <video src="Design sem nome (2).mp4" autoplay loop muted></video>
        </div>
        <div class="box">
            <div class="conteudo">
                <div class="container">
                    <form action="session.php" method="post">
                        <h1>Login</h1>
                        <div class="input-container">
                            <input type="text" name="utilizador" id="utilizador" placeholder="Nome de Utilizador" size="25">
                            <img width="20" height="20" src="https://img.icons8.com/ios-glyphs/30/user--v1.png"
                                alt="user--v1" />
                        </div>

                        <div class="input-container">
                            <input type="password" name="password" id="password" placeholder="PassWord" size="26">
                            <img width="20" height="20" src="https://img.icons8.com/ios-filled/50/lock.png"
                                alt="lock" /> 

                            <a href="pass.html">Esqueci a minha senha</a>
                        </div>

                        <button type="submit" class="submit-button">Entrar</button>

                        <div>
                            <p class="oi">Não está cadastrado? <a href="registar_utilizador.php">Cadastrar</a> </p>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </section>


</body>

</html>