


<?php
function LigaBD() {
    $host = 'localhost'; // Endereço do servidor
    $usuario = 'root';   // Usuário do banco de dados
    $senha = '';         // Senha do banco de dados
    $banco = 'caminhodosucesso'; // Nome do banco de dados

    $con = new mysqli($host, $usuario, $senha, $banco);

    // Verifica conexão
    if ($con->connect_error) {
        die('Erro ao conectar ao banco de dados: ' . $con->connect_error);
    }

    return $con;
}
?>
