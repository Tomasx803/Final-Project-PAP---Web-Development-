<?php
require_once 'ligacaoBD.php';
require_once 'testaSessao.php';

if(testa()){
    if(isset($_GET["id"])){
        $operacao = "update";
        $con = LigaBD();

        // Check if the connection is valid
        if ($con === false) {
            die('Connection failed: ' . mysqli_connect_error());
        }

        $stm = $con->prepare("SELECT * FROM cursos WHERE id_cursos = ?");
        if ($stm === false) {
            die('Prepare failed: ' . $con->error);  // Check if the query preparation fails
        }       

        $stm->bind_param("i", $_GET["id_cursos"]);
        $stm->execute();
        $res = $stm->get_result();
        $resultados = $res->fetch_assoc();
        $stm->close();
        $con->close();

    } else {
        $operacao = "insert";
    }   

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        require("validacao.php");
        $validacao = validarFormulario();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Registar Cursos</title>
    <link rel="stylesheet" href="registrar.css">
</head>
<style>
    .erro {
        color: red;
    }
</style>

<body>

<section>
        <div class="background-section">
            <video src="Design sem nome (2).mp4" autoplay loop muted></video>
        </div>
        <div class="box">
            <div class="conteudo">
                <div class="container">
                    
                <form action="<?php echo ($operacao == "update") ? $_SERVER["PHP_SELF"] . "?id=" . $_GET["id_cursos"] : $_SERVER["PHP_SELF"]; ?>" method="post">
                       <h1>Registar Curso</h1>
                       <?php
                            if ($_POST && in_array("nome_curso", $validacao)) {
                                echo "<span class=\"erro\">(Preenchimento obrigatório)</span>";
                            }
                        ?>
                        <div class="input-container">
                        <input type="text" name="nome_curso" placeholder="Inserir Nome do Curso" size="26" value="<?php 
                            if ($_POST) {
                                if (!empty($_POST["nome_curso"])) {
                                    echo $_POST["nome_curso"];
                                }
                            } else if ($operacao == "update") {
                                echo $resultados["nome_curso"];
                            }
                        ?>">
                        </div>

                        <?php   
                            if ($_POST && in_array("tipo_area", $validacao)) 
                                echo "<span class=\"erro\">(Preenchimento obrigatório)</span>";
                        ?>  
                        <div class="input-container">
                        <input type="text" name="tipo_area" placeholder="Inserir tipo de area" size="26" value="<?php 
                            if ($_POST) {
                                if (!empty($_POST["tipo_area"])) {
                                    echo $_POST["tipo_area"];
                                }
                            } else if ($operacao == "update") {
                                echo $resultados["tipo_area"];
                            }
                        ?>">
                        </div>

                        <?php 
                            if ($_POST && in_array("material_estudo", $validacao)) 
                                echo "<span class=\"erro\">(Preenchimento obrigatório)</span>";
                        ?>
                        <div class="input-container">
                        <input type="text" name="material_estudo" placeholder="Inserir material de estudo" size="26" value="<?php 
                            if ($_POST) {
                                if (!empty($_POST["material_estudo"])) {
                                    echo $_POST["material_estudo"];
                                }
                            } else if ($operacao == "update") {
                                echo $resultados["material_estudo"];
                            }
                        ?>">
                        </div>  
                        <?php 
                            if ($_POST && in_array("nome_mentor", $validacao)) 
                                echo "<span class=\"erro\">(Preenchimento obrigatório)</span>";
                        ?>
                        <div class="input-container">
                        <input type="text" name="nome_mentor" placeholder="Inserir nome do mentor" size="26" value="<?php 
                            if ($_POST) {
                                if (!empty($_POST["nome_mentor"])) {
                                    echo $_POST["nome_mentor"];
                                }
                            } else if ($operacao == "update") {
                                echo $resultados["nome_mentor"];
                            }
                        ?>">
                        </div>

                        <br/>
                        <button type="submit" class="submit-button">Registar</button>
                        <button type="reset" class="submit-button">Limpar</button>
                        <p class="oil">
                           <Strong> <a href="mostrarcursos.php">Voltar</a></Strong>
                            <!--<a href="mostrarcurso.php" title="Cursos"><strong><font color="#FFFFFF">Voltar</font></strong></a>-->
                        </p>
                    </form>

                    <?php 
                    if ($_POST && count($validacao) == 0) {
                        $con = LigaBD();

                        // Check for valid connection
                        if ($con === false) {
                            die('Connection failed: ' . mysqli_connect_error());
                        }

                        if ($operacao == "insert") {
                            // Fixed INSERT query: Ensure the column count matches the value count
                            $stm = $con->prepare("INSERT INTO cursos (nome_curso, tipo_area, material_estudo, nome_mentor) VALUES (?, ?, ?, ?)");

                            if ($stm === false) {
                                die('Prepare failed: ' . $con->error); // Check if query preparation fails
                            }   

                            $stm->bind_param("ssss", $_POST["nome_curso"], $_POST["tipo_area"], $_POST["material_estudo"], $_POST["nome_mentor"]);

                            if ($stm->execute()) {
                                header("Location: mostrarcursos.php");
                            } else {
                                echo "Ocorreu um erro ao inserir o registo.";
                                header( "Refresh: 5; url=mostrarcursos.php");
                            }

                            $stm->close();
                        }

                        if ($operacao == "update") {
                            // Fixed UPDATE query: Ensure the column count matches the value count
                            $stm = $con->prepare("UPDATE cursos SET nome_curso = ?, tipo_area = ?, material_estudo = ?, nome_mentor = ? WHERE id_cursos = ?");

                            if ($stm === false) {
                                die('Prepare failed: ' . $con->error); // Check if query preparation fails
                            }

                            $stm->bind_param("ssssi", $_POST["nome_curso"], $_POST["tipo_area"], $_POST["material_estudo"], $_POST["nome_mentor"], $_GET["id_cursos"]);

                            if ($stm->execute()) {
                                header("Location: mostrarcursos.php");
                            } else {
                                echo "Ocorreu um erro ao atualizar o registo.";
                                header("Refresh: 5; url=mostrarcursos.php");
                            }

                            $stm->close();
                        }

                        $con->close();
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>

</body>
</html>