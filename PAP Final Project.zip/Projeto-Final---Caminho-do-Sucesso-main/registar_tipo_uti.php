<?php
require_once 'ligacaoBD.php';
require_once 'testaSessao.php';

if (testa()) {
    $operacao = isset($_GET["id"]) ? "update" : "insert";
    $resultados = [];

    if ($operacao === "update") {
        $con = LigaBD();
        if ($con === false) {
            die('Connection failed: ' . mysqli_connect_error());
        }

        $stm = $con->prepare("SELECT * FROM users WHERE id_users = ?");
        if ($stm === false) {
            die('Prepare failed: ' . $con->error);
        }

        $stm->bind_param("i", $_GET["id"]);
        $stm->execute();
        $res = $stm->get_result();
        $resultados = $res->fetch_assoc();
        $stm->close();
        $con->close();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        require("validacao.php");
        $validacao = validarFormulario();
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <title>Registrar Cursos</title>
    <link rel="stylesheet" href="registrar.css">
    <style>
        .erro {
            color: red;
        }
    </style>
</head>
<body>
<section>
    <div class="background-section">
        <video src="Design sem nome (2).mp4" autoplay loop muted></video>
    </div>
    <div class="box">
        <div class="conteudo">
            <div class="container">
                <form action="<?php echo ($operacao === "update") ? $_SERVER["PHP_SELF"] . "?id=" . $_GET["id"] : $_SERVER["PHP_SELF"]; ?>" method="post">
                    <h1>Cadastrar</h1>

                    <!-- Nome do usuário -->
                    <?php if ($_POST && in_array("user_name", $validacao)) echo "<span class='erro'>(Preenchimento obrigatório)</span>"; ?>
                    <div class="input-container">
                        <input type="text" name="user_name" placeholder="Inserir nome de utilizador" size="26" value="<?php echo $_POST['user_name'] ?? $resultados['user_name'] ?? ''; ?>">
                    </div>

                    <!-- E-mail -->
                    <?php if ($_POST && in_array("email", $validacao)) echo "<span class='erro'>(Preenchimento obrigatório)</span>"; ?>
                    <div class="input-container">
                        <input type="email" name="email" placeholder="Inserir E-mail" size="26" value="<?php echo $_POST['email'] ?? $resultados['email'] ?? ''; ?>">
                    </div>

                    <!-- Senha -->
                    <?php if ($_POST && in_array("password_senha", $validacao)) echo "<span class='erro'>(Preenchimento obrigatório)</span>"; ?>
                    <div class="input-container">
                        <input type="password" name="password_senha" placeholder="Inserir senha" size="26" value="<?php echo $_POST['password_senha'] ?? $resultados['password_senha'] ?? ''; ?>">
                    </div>

                    <!-- Tipo de usuário -->
                    <?php if ($_POST && in_array("user_type_id", $validacao)) echo "<span class='erro'>(Preenchimento obrigatório)</span>"; ?>
                    <div class="input-container">
                        <input type="text" name="user_type_id" placeholder="Inserir tipo de usuário" size="26" value="<?php echo $_POST['user_type_id'] ?? $resultados['user_type_id'] ?? ''; ?>">
                    </div>

                    <br/>
                    <button type="submit" class="submit-button">Registrar</button>
                    <button type="reset" class="submit-button">Limpar</button>
                    <p class="oil">
                        <strong><a href="http://localhost/Caminho-do-Sucesso/index.html">Voltar</a></strong>
                    </p>
                </form>

                <?php
                if ($_POST && empty($validacao)) {
                    $con = LigaBD();
                    if ($con === false) {
                        die('Connection failed: ' . mysqli_connect_error());
                    }

                    if ($operacao === "insert") {
                        $stm = $con->prepare("INSERT INTO users (user_name, email, password_senha, user_type_id) VALUES (?, ?, ?, ?)");
                        if ($stm === false) {
                            die('Prepare failed: ' . $con->error);
                        }
                        $stm->bind_param("ssss", $_POST["user_name"], $_POST["email"], $_POST["password_senha"], $_POST["user_type_id"]);
                        $stm->execute();
                        $stm->close();
                    } elseif ($operacao === "update") {
                        $stm = $con->prepare("UPDATE users SET user_name = ?, email = ?, password_senha = ?, user_type_id = ? WHERE id_users = ?");
                        if ($stm === false) {
                            die('Prepare failed: ' . $con->error);
                        }
                        $stm->bind_param("ssssi", $_POST["user_name"], $_POST["email"], $_POST["password_senha"], $_POST["user_type_id"], $_GET["id"]);
                        $stm->execute();
                        $stm->close();
                    }

                    $con->close();
                }
                ?>
            </div>
        </div>
    </div>
</section>
</body>
</html>
