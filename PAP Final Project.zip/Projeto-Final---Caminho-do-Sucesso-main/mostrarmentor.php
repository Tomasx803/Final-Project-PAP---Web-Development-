<?php 
    error_reporting(1);
    ob_start();
    session_start();

    // Inclua o arquivo onde a função LigaBD é definida
    include('ligacaobd.php'); // Certifique-se de que 'conexao.php' define a função LigaBD()
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="ISO-8859-1">
    <link rel="stylesheet" href="mos-men.css">
    <title>Mostrar Mentores</title>
    
</head>
<body >

 

    <section>

        <div class="background-section">


            <video src="Design sem nome (2).mp4" autoplay loop muted></video>

        </div>
          
        <div class="box">
            <div class="conteudo">

           
  <h1>Gestão de Mentores</h1>

<?php
    // Verifique se a função LigaBD existe
    if (!function_exists('LigaBD')) {
        die("Erro: A função 'LigaBD' não foi encontrada. Verifique se o arquivo 'conexao.php' foi incluído corretamente.");
    }

    // Conecta ao banco de dados
    if ($con = LigaBD()) {
        // Exclui um mentor, se o ID for passado
        if (isset($_GET["id"])) {
            $stm = $con->prepare("DELETE FROM mentores WHERE nome_do_mentor = ?");
            $stm->bind_param("i", $_GET["id"]);
            $stm->execute();
        }

        // Consulta a tabela de mentores
        $query = $con->query("SELECT * FROM mentores");

        echo '<table>';
        echo '<tr>
                <th>Nome de Mentor</th>
                <th>Senha</th>
                <th>Email</th>
                <th>Editar</th>
                <th>Eliminar</th>
              </tr>';

        // Exibe os resultados
        while ($resultados = $query->fetch_assoc()) {
            echo "<tr>
                    <td>{$resultados['nome_do_mentor']}</td>
                    <td>{$resultados['palavra_chave']}</td>
                    <td>{$resultados['email']}</td>
                    <td><a href='registar_mentor.php?id={$resultados['nome_do_mentor']}'>Editar</a></td>
                    <td><a href='mostrarmentor.php?id={$resultados['nome_do_mentor']}'>Eliminar</a></td>
                  </tr>";
        }

        echo '</table>';
        $con->close();
    } else {
        echo '<p>Erro ao conectar ao banco de dados.</p>';
    }

    ob_end_flush();
?>
        </div>
 </div>

</section>
</body>
</html>