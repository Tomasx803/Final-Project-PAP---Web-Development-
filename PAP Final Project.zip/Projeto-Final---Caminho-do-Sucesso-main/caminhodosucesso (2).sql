-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24-Jan-2025 às 13:26
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `caminhodosucesso`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `areas`
--

CREATE TABLE `areas` (
  `id_area` int(11) NOT NULL,
  `nome_area` varchar(10) NOT NULL,
  `tipo_area` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `areas`
--

INSERT INTO `areas` (`id_area`, `nome_area`, `tipo_area`) VALUES
(1, 'Bernardo', 'Porto');

-- --------------------------------------------------------

--
-- Estrutura da tabela `calendário`
--

CREATE TABLE `calendário` (
  `id` int(11) NOT NULL,
  `id_curso` int(11) NOT NULL,
  `data` time(6) NOT NULL,
  `hora_inicio` time(6) NOT NULL,
  `hora_fim` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `conteudo_curso`
--

CREATE TABLE `conteudo_curso` (
  `id` int(11) NOT NULL,
  `id_curso` int(11) NOT NULL,
  `Nº_horas` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `contéudo`
--

CREATE TABLE `contéudo` (
  `id` int(11) NOT NULL,
  `Designação` varchar(45) NOT NULL,
  `Cod - Area` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursos`
--

CREATE TABLE `cursos` (
  `nome_curso` varchar(75) NOT NULL,
  `id_cursos` int(11) NOT NULL,
  `tipo_area` varchar(75) NOT NULL,
  `material_estudo` varchar(75) NOT NULL,
  `nome_mentor` varchar(30) NOT NULL,
  `Imagem` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `cursos`
--

INSERT INTO `cursos` (`nome_curso`, `id_cursos`, `tipo_area`, `material_estudo`, `nome_mentor`, `Imagem`) VALUES
('Tecnologia', 0, 'Programação', 'Codigo Visual Studio', 'Tomás Ramos', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `socio`
--

CREATE TABLE `socio` (
  `id_socio` int(11) NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `apelido` varchar(45) NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `qpagas` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Extraindo dados da tabela `socio`
--

INSERT INTO `socio` (`id_socio`, `Nome`, `apelido`, `sexo`, `qpagas`) VALUES
(2, 'José', 'António', 'M', 'N');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo`
--

CREATE TABLE `tipo` (
  `id` int(11) NOT NULL,
  `Designação` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tipo`
--

INSERT INTO `tipo` (`id`, `Designação`) VALUES
(6, 'Aluno'),
(7, 'Mentor'),
(8, 'Colaborador A'),
(9, 'Colaborador B'),
(10, 'Administrador');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipoutilizadores`
--

CREATE TABLE `tipoutilizadores` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_types`
--

CREATE TABLE `user_types` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizadores`
--

CREATE TABLE `utilizadores` (
  `id_utilizador` int(11) NOT NULL,
  `nome_utilizador` varchar(75) NOT NULL,
  `palavra_chave` varchar(20) NOT NULL,
  `email` varchar(75) NOT NULL,
  `id_tipo` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Extraindo dados da tabela `utilizadores`
--

INSERT INTO `utilizadores` (`id_utilizador`, `nome_utilizador`, `palavra_chave`, `email`, `id_tipo`) VALUES
(35, 'Gabriel Oliveira', 'Abacate@eu', 'GabrielOliveira@gmail.com', '3'),
(34, 'Gabriel Oliveira', 'Abacate@eu', 'GabrielOliveira@gmail.com', '2'),
(33, 'Tomás Ramos', '1234', 'TomasRamos@exemplo.com', '5'),
(32, 'Gabriel Oliveira', 'Abacate@eu', 'GabrielOliveira@gmail.com', '5');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id_cursos`);

--
-- Índices para tabela `socio`
--
ALTER TABLE `socio`
  ADD PRIMARY KEY (`id_socio`);

--
-- Índices para tabela `tipo`
--
ALTER TABLE `tipo`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `user_types`
--
ALTER TABLE `user_types`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  ADD PRIMARY KEY (`id_utilizador`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `socio`
--
ALTER TABLE `socio`
  MODIFY `id_socio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tipo`
--
ALTER TABLE `tipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `user_types`
--
ALTER TABLE `user_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  MODIFY `id_utilizador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
