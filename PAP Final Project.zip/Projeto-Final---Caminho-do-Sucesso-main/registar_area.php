<?php
require_once 'ligacaoBD.php';
require_once 'testaSessao.php';

if(testa()){
    if(isset($_GET["id_area"])){
        $operacao = "update";
        $con = LigaBD();

        // Check if the connection is valid
        if ($con === false) {
            die('Connection failed: ' . mysqli_connect_error());
        }

        $stm = $con->prepare("SELECT * FROM areas WHERE id_area = ?");
        if ($stm === false) {
            die('Prepare failed: ' . $con->error);  // Check if the query preparation fails
        }

        $stm->bind_param("i", $_GET["id_area"]);
        $stm->execute();
        $res = $stm->get_result();
        $resultados = $res->fetch_assoc();
        $stm->close();
        $con->close();
    } else {
        $operacao = "insert";
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        require("validacao.php");
        $validacao = validarFormulario();
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Registar Áreas</title>
    <link rel="stylesheet" href="registrar.css">
</head>
<style>
    .erro {
        color: red;
    }
</style>

<body>

<section>
        <div class="background-section">
            <video src="Design sem nome (2).mp4" autoplay loop muted></video>
        </div>
        <div class="box">
            <div class="conteudo">
                <div class="container">
                    
                <form action="<?php echo ($operacao == "update") ? $_SERVER["PHP_SELF"] . "?id=" . $_GET["id_area"] : $_SERVER["PHP_SELF"]; ?>" method="post">
                       <h1>Registar Área</h1>
                       <?php
                            if ($_POST && in_array("nome_area", $validacao)) {
                                echo "<span class=\"erro\">(Preenchimento obrigatório)</span>";
                            }
                        ?>
                        <div class="input-container">
                        <input type="text" name="nome_area" placeholder="Inserir Nome da Area" size="26" value="<?php 
                            if ($_POST) {
                                if (!empty($_POST["nome_area"])) {
                                    echo $_POST["nome_area"];
                                }
                            } else if ($operacao == "update") {
                                echo $resultados["nome_area"];
                            }
                        ?>">
                        </div>

                        <?php 
                            if ($_POST && in_array("tipo_area", $validacao)) 
                                echo "<span class=\"erro\">(Preenchimento obrigatório)</span>";
                        ?>
                        <div class="input-container">
                        <input type="text" name="tipo_area" placeholder="Inserir tipo de Area" size="26" value="<?php 
                            if ($_POST) {
                                if (!empty($_POST["tipo_area"])) {
                                    echo $_POST["tipo_area"];
                                }
                            } else if ($operacao == "update") {
                                echo $resultados["tipo_area"];
                            }
                        ?>">
                        </div>
                        
                        <br>
                        <button type="submit" class="submit-button">Registar</button>
                        <button type="reset" class="submit-button">Limpar</button>
                        <p class="oil">
                           <Strong> <a href="http://localhost/Caminho-do-Sucesso/index.html">Voltar</a></Strong>
                            <!--<a href="mostrarutilizadotor.php" title="Utilizadores"><strong><font color="#FFFFFF">Voltar</font></strong></a>-->
                        </p>
                    </form>

                    <?php 
                    if ($_POST && count($validacao) == 0) {
                        $con = LigaBD();

                        // Check for valid connection
                        if ($con === false) {
                            die('Connection failed: ' . mysqli_connect_error());
                        }

                        if ($operacao == "insert") {
                            // Fixed INSERT query: Ensure the column count matches the value count
                            $stm = $con->prepare("INSERT INTO areas (nome_area, tipo_area) VALUES (?, ?)");

                            if ($stm === false) {
                                die('Prepare failed: ' . $con->error); // Check if query preparation fails
                            }

                            $stm->bind_param("ss", $_POST["nome_area"], $_POST["tipo_area"]);

                            if ($stm->execute()) {
                                header("Location: mostrarareas.php");
                            } else {
                                echo "Ocorreu um erro ao inserir o registo.";
                                header("Refresh: 5; url=mostrarareas.php");
                            }

                            $stm->close();
                        }

                        if ($operacao == "update") {
                            // Fixed UPDATE query: Ensure the column count matches the value count
                            $stm = $con->prepare("UPDATE areas SET nome_area = ?, tipo_area = ? WHERE id_area = ?");

                            if ($stm === false) {
                                die('Prepare failed: ' . $con->error); // Check if query preparation fails
                            }

                            $stm->bind_param("ssi", $_POST["nome_area"], $_POST["tipo_area"], $_GET["id_area"]);

                            if ($stm->execute()) {
                                header("Location: mostrararea.php");
                            } else {
                                echo "Ocorreu um erro ao atualizar o registo.";
                                header("Refresh: 5; url=mostrararea.php");
                            }

                            $stm->close();
                        }

                        $con->close();
                    }
                    ?>
                </div>
            </div>
        </div>
    </section>

</body>
</html>