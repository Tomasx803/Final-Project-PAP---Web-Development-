<?php
require_once 'ligacaoBD.php';
require_once 'testaSessao.php';

// Define o valor padrão da variável $operacao
$operacao = "insert"; 

// Inicializa $validacao como um array vazio
$validacao = [];

if (testa()) {
    if (isset($_GET["id"])) {
        $operacao = "update";
        $con = LigaBD();

        if ($con === false) {
            die('Connection failed: ' . mysqli_connect_error());
        }

        $stm = $con->prepare("SELECT * FROM Utilizadores WHERE id_utilizador = ?");
        if ($stm === false) {
            die('Prepare failed: ' . $con->error);
        }

        $stm->bind_param("i", $_GET["id"]);
        $stm->execute();
        $res = $stm->get_result();
        $resultados = $res->fetch_assoc();
        $stm->close();
        $con->close();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require("validacao.php");
    $validacao = validarFormulario();

    if (!is_array($validacao)) {
        $validacao = [];
    }
}
?>

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Registar Utilizadores</title>
    <link rel="stylesheet" href="registrar.css">
</head>
<style>
    .erro {
        color: red;
    }
</style>
<body>
<script>
    var subjectObject = {
        1: "Aluno",
        2: "Mentor",
        3: "Colaborador A",
        4: "Colaborador B",
        5: "Administrador"
    };

    window.onload = function () {
        var subjectSel = document.getElementById("id_tipo");
        for (var key in subjectObject) {
            var option = new Option(subjectObject[key], key);
            subjectSel.options.add(option);
        }
    }
</script>

<section>
    <div class="background-section">
        <video src="Design sem nome (2).mp4" autoplay loop muted></video>
    </div>
    <div class="box">
        <div class="conteudo">
            <div class="container">
                <form action="<?php echo ($operacao == "update") ? $_SERVER["PHP_SELF"] . "?id=" . $_GET["id"] : $_SERVER["PHP_SELF"]; ?>" method="post">
                    <h1>Registar Utilizador</h1>
                    <!-- Nome Utilizador -->
                    <div class="input-container">
                        <input type="text" name="nome_utilizador" placeholder="Inserir Nome do Utilizador" size="26" value="<?php 
                            if ($_POST) {
                                echo $_POST["nome_utilizador"] ?? '';
                            } else if ($operacao == "update") {
                                echo $resultados["nome_utilizador"];
                            }
                        ?>">
                        <?php if ($_POST && in_array("nome_utilizador", $validacao)) echo "<span class=\"erro\">(Preenchimento obrigatório)</span>"; ?>
                    </div>

                    <!-- Palavra-passe -->
                    <div class="input-container">
                        <input type="password" name="palavra_chave" placeholder="Inserir Palavra-passe" size="26" value="<?php 
                            if ($_POST) {
                                echo $_POST["palavra_chave"] ?? '';
                            } else if ($operacao == "update") {
                                echo $resultados["palavra_chave"];
                            }
                        ?>">
                        <?php if ($_POST && in_array("palavra_chave", $validacao)) echo "<span class=\"erro\">(Preenchimento obrigatório)</span>"; ?>
                    </div>

                    <!-- Email -->
                    <div class="input-container">
                        <input type="email" name="email" placeholder="Inserir Endereço de E-mail" size="26" value="<?php 
                            if ($_POST) {
                                echo $_POST["email"] ?? '';
                            } else if ($operacao == "update") {
                                echo $resultados["email"];
                            }
                        ?>">
                        <?php if ($_POST && in_array("email", $validacao)) echo "<span class=\"erro\">(Preenchimento obrigatório)</span>"; ?>
                    </div>

                    <!-- Tipo de Utilizador -->
                    <div class="input-container">
                        <select class="styled-select" id="id_tipo" name="id_tipo">
                            <option value="">Selecione o Tipo de Utilizador</option>
                        </select>
                        <?php if ($_POST && in_array("id_tipo", $validacao)) echo "<span class=\"erro\">(Preenchimento obrigatório)</span>"; ?>
                    </div>

                    <br/>
                    <button type="submit" class="submit-button">Registar</button>
                    <button type="reset" class="submit-button">Limpar</button>
                    <p class="oil">
                        <strong><a href="mostrarutilizadotor.php">Voltar</a></strong>
                    </p>
                </form>

                <?php 
                if ($_POST && count($validacao) == 0) {
                    $con = LigaBD();

                    if ($con === false) {
                        die('Connection failed: ' . mysqli_connect_error());
                    }

                    if ($operacao == "insert") {
                        $stm = $con->prepare("INSERT INTO utilizadores (nome_utilizador, palavra_chave, email, id_tipo) VALUES (?, ?, ?, ?)");

                        if ($stm === false) {
                            die('Prepare failed: ' . $con->error);
                        }

                        $stm->bind_param("sssi", $_POST["nome_utilizador"], $_POST["palavra_chave"], $_POST["email"], $_POST["id_tipo"]);
                        $stm->execute();
                        header("Location: posregisto.html");
                        $stm->close();
                    }

                    if ($operacao == "update") {
                        $stm = $con->prepare("UPDATE utilizadores SET nome_utilizador = ?, palavra_chave = ?, email = ?, id_tipo = ? WHERE id_utilizador = ?");

                        if ($stm === false) {
                            die('Prepare failed: ' . $con->error);
                        }

                        $stm->bind_param("sssii", $_POST["nome_utilizador"], $_POST["palavra_chave"], $_POST["email"], $_POST["id_tipo"], $_GET["id"]);
                        $stm->execute();
                        header("Location: mostrarutilizadotor.php");
                        $stm->close();
                    }

                    $con->close();
                }
                ?>
            </div>
        </div>
    </div>
</section>

</body>
</html>