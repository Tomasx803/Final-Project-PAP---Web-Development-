<!DOCTYPE html>
<html lang="pt-br">



<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">



<body>



    <section>

        <div class="background-section">


            <video src="Design sem nome (2).mp4" autoplay loop muted></video>

        </div>
        <div class="box">
            <div class="header">
                <header>
                    <div class="navbar">

                        <div class="logo"><a href="#">Caminho Do Sucesso</a></div>
                        <ul class="links">
                            <li><a href="index.html">Home</a></li>
                            <li><a href="cursos.html">Cursos</a></li>
                            <li><a href="mentores.html">Mentores</a></li>
                            <li><a href="sobrenos.html">Sobre Nós</a></li>
                            <li><a href="contactos.html">Contactos</a></li>
                        </ul>
                        <a href="login.html" class="action_btn">Get Started</a>
                        <div class="toggle_btn">
                            <i class="fa-solid fa-bars"></i>
                        </div>

                    </div>

                    <div class="dropdown_menu">
                        <ul class="links"></ul>
                        <li><a href="index.html">Home</a></li>
                            <li><a href="cursos.html">Cursos</a></li>
                            <li><a href="mentores.html">Mentores</a></li>
                            <li><a href="sobrenos.html">Sobre Nós</a></li>
                            <li><a href="contactos.html">Contactos</a></li>
                        <li><a href="login.html" class="action_btn">Get Started</a></li>
                        </ul>
                    </div>

                </header>
                <script>
                    const toggleBtn = document.querySelector('.toggle_btn')
                    const toggleBtnIcon = document.querySelector('.toggle_btn i')
                    const dropdownMenu = document.querySelector('.dropdown_menu')

                    toggleBtn.onclick = function () {
                        dropdownMenu.classList.toggle('open')
                        const isOpen = dropdownMenu.classList.contains('open')

                        toggleBtnIcon.classList = isOpen
                            ? 'fa-solid fa-xmark'
                            : 'fa-solid fa-bars'
                    }
                </script>
            </div>
            <div class="conteudo">
               
              <?php
    require_once 'ligacaobd.php';
    require_once 'testasessao.php';

    if(testa())
    {
        if($con = LigaBD())
        {
            if(isset($_GET["id"]))
            {
                $stm = $con->prepare("delete from socio where id_socio=?");
                $stm->bind_param("i", $_GET["id"]);
                $stm->execute();
            }

            $query = $con->query("select * from socio");

            echo '<h1><center><font color= "#fff">Gestão de Sócios</font></h1></center><br />';
            echo '<center>  </center>';
            echo '<p align="right"><h4><a href="login.php">Login</a>&nbsp;&nbsp;<a href="registar_socio.php">Registar Sócio</a></h4></p><br></br>';

            echo '<table style= "border: 2px solid rgba(255, 255, 255, .2)"><tr><th>Nome de sócio</th><th>Sobrenome</th><th>Sexo</th><th>Email</th><th>Quotas pagas</th><th>Editar</th><th>Eliminar</th></tr>';

            while($resultados = $query->fetch_assoc())
            {    
                                            
                echo  "<tr><td>" . $resultados['Nome'] . "</td><td>" . $resultados['apelido'] . "</td><td>" .
                     $resultados['sexo'] . "</td><td>" .
                     $resultados['qpagas'] . "</td><td><a href = 'registar_socio.php?id=" . 
                     $resultados['id_socio'] . "'>Editar<a></td><td><a href ='mostrarsocio.php?id=" .
                     $resultados['id_socio'] . "'>Eliminar<a></td>";
            }

            echo "</table>";
            $con->close();
        }
        echo "<br></br>";
    }

    ob_end_flush();
?>  

                
            </div>
        </div>



    </section>


</body>

</html>


