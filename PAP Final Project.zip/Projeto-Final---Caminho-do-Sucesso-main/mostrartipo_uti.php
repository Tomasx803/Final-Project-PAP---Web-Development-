<?php 
    error_reporting(1);
    ob_start();
    session_start();

    // Inclua o arquivo onde a função LigaBD é definida
    include('ligacaobd.php'); // Certifique-se de que 'conexao.php' define a função LigaBD()
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="ISO-8859-1">
    <link rel="stylesheet" href="mos-tipo-ultili.css">
    <title>Tipos de  Utilizador</title>
    
</head>
<body >

 

    <section>

        <div class="background-section">


            <video src="Design sem nome (2).mp4" autoplay loop muted></video>

        </div>
          
        <div class="box">
            <div class="conteudo">

           
  <h1>Gestão de Utilizadores</h1>

<?php
    // Verifique se a função LigaBD existe
    if (!function_exists('LigaBD')) {
        die("Erro: A função 'LigaBD' não foi encontrada. Verifique se o arquivo 'conexao.php' foi incluído corretamente.");
    }

    // Conecta ao banco de dados
    if ($con = LigaBD()) {
        // Exclui um utilizador, se o ID for passado
        if (isset($_GET["id"])) {
            $stm = $con->prepare("DELETE FROM users WHERE id = ?");
            $stm->bind_param("i", $_GET["id"]);
            $stm->execute();
        }

        // Consulta a tabela de tipo_utilizador
        $query = $con->query("SELECT * FROM users");

        echo '<table>';
        echo '<tr>
                <th>ID</th>
                <th>Nome do Utilizador</th>
                <th>E-Mail</th>
                <th>Senha</th>
                <th>Tipo de Utilizador</th>
                <th>Criação da Conta</th>
                <th>Ultimo Update</th>
                <th> Editar</th>
                <th>Eliminar</th>
              </tr>';

        // Exibe os resultados
        while ($resultados = $query->fetch_assoc()) {
            echo "<tr>
                    <td>{$resultados['id']}</td>
                    <td>{$resultados['name']}</td>
                    <td>{$resultados['email']}</td>
                    <td>{$resultados['password']}</td>
                    <td>{$resultados['user_type_id']}</td>
                    <td>{$resultados['created_at']}</td>
                    <td>{$resultados['updated_at']}</td>
                    <td><a href='registar_tipo_uti.php?id={$resultados['id']}'>Editar</a></td>
                    <td><a href='mostrartipo_uti.php?id={$resultados['id']}'>Eliminar</a></td>
                  </tr>";
        }

        echo '</table>';
        $con->close();
    } else {
        echo '<p>Erro ao conectar ao banco de dados.</p>';
    }

    ob_end_flush();
?>
        </div>
 </div>


</section>

</body>
</html>
