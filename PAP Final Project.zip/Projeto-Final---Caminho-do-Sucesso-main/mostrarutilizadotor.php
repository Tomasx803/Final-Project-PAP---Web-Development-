<?php
error_reporting(E_ALL);
ob_start();
session_start();

// Inclua o arquivo de conexão
include('ligacaobd.php');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="ISO-8859-1">
    <link rel="stylesheet" href="mos-ultili.css">
    <title>Mostrar Utilizadores</title>
</head>
<body>
    <section>
        <div class="background-section">
            <video src="Design sem nome (2).mp4" autoplay loop muted></video>
        </div>
        <div class="box">
            <div class="conteudo">
                <h1>Gestão de Utilizadores</h1>

                <div class="btn-voltar">
            <!-- Use a tag <a> corretamente para links -->
            <a href="Gestaobase.html" class="action_btn">Voltar</a>
        </div>

        <div class="btn-registar">
            <!-- Use a tag <a> corretamente para links -->
            <a href="registar_utilizador.php" class="action_btn2">Registar</a>
        </div>

                <?php
                if ($con = LigaBD()) {
                    // Verifica se há um pedido para excluir
                    if (isset($_GET["id"])) {
                        $stm = $con->prepare("DELETE FROM utilizadores WHERE id_utilizador = ?");
                        $stm->bind_param("i", $_GET["id"]);
                        $stm->execute();
                        $stm->close();
                    }

                    // Consulta os dados da tabela
                    $query = $con->query("
                        SELECT 
                            u.nome_utilizador, 
                            u.palavra_chave, 
                            u.email, 
                            t.Designação AS tipo_utilizador,
                            u.id_utilizador
                        FROM 
                            utilizadores u
                        LEFT JOIN 
                            tipo t ON u.id_tipo = t.id
                    ");

                    if ($query && $query->num_rows > 0) {
                        echo '<table>';
                        echo '<tr>
                                <th>Nome de Utilizador</th>
                                <th>Senha</th>
                                <th>Email</th>
                                <th>Tipo de Utilizador</th>
                                <th>Editar</th>
                                <th>Eliminar</th>
                              </tr>';

                        while ($resultados = $query->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$resultados['nome_utilizador']}</td>
                                    <td>{$resultados['palavra_chave']}</td>
                                    <td>{$resultados['email']}</td>
                                    <td>{$resultados['tipo_utilizador']}</td>
                                    <td><a href='registar_utilizador.php?' id={$resultados['id_utilizador']}
                                    
                                    <div class='btn-editar'>Editar</a></td>

                                    <td><button class='btn-eliminar' data-id='{$resultados['id_utilizador']}'>Eliminar</button></td>

                                  </tr>";
                        }

                        echo '</table>';
                    } else {
                        echo '<p>Nenhum utilizador encontrado.</p>';
                    }

                    $con->close();
                } else {
                    echo '<p>Erro ao conectar ao banco de dados.</p>';
                }

                ob_end_flush();
                ?>
            </div>
        </div>

    </section>

    <!-- Pop-up : "Tem a certeza que quer excluir? - Sim ou Não"-->
    <div class="modal-overlay" id="modalOverlay"></div>
    <div class="modal" id="confirmationModal">
        <div class="modal-content">
            <p>Tem a certeza que quer eliminar?</p>
            <button id="confirmYes">Sim</button>
            <button id="confirmNo">Não</button>
        </div>
    </div>

    <script>

        // Codigo de confirmaçao : "Tem a certeza que quer excluir? - Sim ou Não"
        const modal = document.getElementById("confirmationModal");
        const overlay = document.getElementById("modalOverlay");
        const confirmYes = document.getElementById("confirmYes");
        const confirmNo = document.getElementById("confirmNo");
        let deleteId = null;

        // Codigo para excluir os botões
        document.querySelectorAll(".btn-eliminar").forEach(button => {
            button.addEventListener("click", function () {
                deleteId = this.getAttribute("data-id"); // Obter o código do curso 
                modal.style.display = "block";
                overlay.style.display = "block"; 
            });
        });

        // Confirmação para excluir os botões
        confirmYes.addEventListener("click", function () {
            if (deleteId) {
                window.location.href = `mostrarutilizadotor.php?id=${deleteId}`;
            }
        });

        // Cancelar a exclusão dos botões
        confirmNo.addEventListener("click", function () {
            modal.style.display = "none"; 
            overlay.style.display = "none";
            deleteId = null; // Redefinir ID
        });

        // Ocultar a mensagem quando é clicada (Sobrepoe-se a confirmação do texto)
        overlay.addEventListener("click", function () {
            modal.style.display = "none";
            overlay.style.display = "none";
            deleteId = null; // Redefinir ID
        });

    </script>
</body>
</html>

